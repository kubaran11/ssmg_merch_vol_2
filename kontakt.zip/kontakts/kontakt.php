<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/kontakt.css">
    <title>Kontakty</title>
</head>
<body>

    <div class = "map_kontakt">

        
        <div class = "map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1280.2783502428645!2d14.878037739621009!3d50.07586315854835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x470c0b183eb23139%3A0xec8658e236d368e!2zU3TFmWVkbsOtIE9kYm9ybsOhIMWga29sYQ!5e0!3m2!1scs!2scz!4v1666268489875!5m2!1scs!2scz" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <div class = "kontakt">
            <div class = "kontakt_text">
                <h1>Kontaktujte nás</h1>
            </div>
            <div class = "kontakt_items">
                <div class = "adress">
                    <img src="../images/house_icon.png" alt="house">
                    <p> Český Brod - Liblice, Školní 145/28200 </p>
                </div>
                <div class = "mail">
                    <img src="../images/mail_icon.png" alt="mail_icon">
                    <p> info@sosceskybrod.cz </p>
                </div>
                <div class = "phone_n">
                    <img src="../images/phone_icon.png" alt="phone">
                    <p> +420 123 456 789 </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>